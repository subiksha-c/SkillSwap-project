// routes/skills.js
const express = require("express");
const db = require("../db");

const router = express.Router();

// Add new skill
router.post("/add", async (req, res) => {
  const { user_id, skill_name, description } = req.body;

  try {
    await db.query("INSERT INTO skills (user_id, skill_name, description) VALUES (?, ?, ?)", 
      [user_id, skill_name, description]);
    res.json({ message: "✅ Skill added successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Adding skill failed" });
  }
});

// Get all skills
router.get("/", async (req, res) => {
  try {
    const [rows] = await db.query("SELECT s.id, s.skill_name, s.description, u.username FROM skills s JOIN users u ON s.user_id = u.id");
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Fetching skills failed" });
  }
});

module.exports = router;
